public class Estadio {
    private String nome;
    private int capacidade;
    private double precoIngresso;

    public String nome(){
        return this.nome;
    }
    public int capacidade(){
        return this.capacidade;
    }
    public double precoIngresso(){
        return this.precoIngresso;
    }

}