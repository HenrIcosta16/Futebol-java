import java.util.ArrayList;
import java.util.List;

public class Rodada {
    List<Partida> partidas;
    int mediaGols;

    public Rodada() {
        partidas = new ArrayList<>();
    }
}
