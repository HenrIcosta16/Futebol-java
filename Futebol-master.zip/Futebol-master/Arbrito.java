public class Arbrito{
    private String nome;
    private int idade;

    public String nome(){
       return this.nome;
    }
    public int idade(){
        return this.idade;
    }

}